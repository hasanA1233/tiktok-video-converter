# snaptik-app-api
> A no-watermark TikTok video downloader based on reverse-engineering SnapTik (snaptik.app)